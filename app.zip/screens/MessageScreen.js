import {
  StyleSheet,
  View,
  ScrollView,
  KeyboardAvoidingView,
  TextInput,
  Pressable,
  Image,
  TouchableOpacity,
  TouchableWithoutFeedback,
  Modal,
  Platform,
  Alert,
  BackHandler,
  Linking,
} from "react-native";
import React, { useState, useContext, useLayoutEffect, useEffect,useRef } from "react";
import { Ionicons } from "@expo/vector-icons";
import { Entypo } from "@expo/vector-icons";
import EmojiSelector from "react-native-emoji-selector";
import { useNavigation, useRoute } from "@react-navigation/native";
import { UserType } from "../Context/UserContext";
import axios from "axios";
import { mainURL } from "../Utils/urls";
import { Box,Button,Icon,IconButton,Menu,Text } from "native-base";
import * as ImagePicker from "expo-image-picker"
import { ResizeMode, Video } from 'expo-av';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { io } from "socket.io-client";
import moment from 'moment';
import * as DocumentPicker from 'expo-document-picker';
const MessageSrceen = () => {
  const [showEmojiSelector, setShowEmojiSelector] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [showUnStar, setShowUnStar]=useState(false);
  const [isReplyPressed, setIsReplyPressed] = useState(false);

  const [selectedImage, setSelectedImage] = useState("")
  const [message, setMessage] = useState("");

  const [starredMessages, setStarredMessages] = useState([]);
  const [getMessage, setGetMessage]=useState([]);
  const [seletedMessages,setSelectedMessages]=useState([]);
  // const [recipentData, setRecipentData]= useState([]);

  const navigation = useNavigation();
  const route = useRoute();
  const scrollViewRef = useRef(null);
  const socket = useRef();
  const {userId, setUserId} = useContext(UserType);

  const [replyMessage, setReplyMessage]=useState(null);
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [videoRef, setVideoRef] = useState(null);
  const [imageRef, setImageRef] = useState(null);
  const [highLight, setHighLight]=useState(null);
  const [document, setDocument] = useState(null);
  
  const { senderId, recipentId, userName } = route.params || {};
  const { highlightedMessageId } = route.params || {};
  
  const scrollToBottom = () => {
    if (scrollViewRef.current) {
        scrollViewRef.current.scrollToEnd({ animated: true });
    }
  };

  const handleReplyPress = (replyMessageId) => {
    setIsReplyPressed(true); 
    const messageIndex = getMessage.findIndex(
      (msg) => msg._id === replyMessageId
    );
  
    if (messageIndex !== -1) {
      scrollViewRef.current?.scrollTo({ y: messageIndex * 80, animated: true }); 
      setHighLight(replyMessageId);
      setTimeout(() => {
      }, 500);
    }
  };

  useEffect(() => {
    if (highlightedMessageId) {
        handleReplyPress(highlightedMessageId);
    }
  }, [highlightedMessageId]);

  useEffect(() => {
    if (!highlightedMessageId && !isReplyPressed) {
        scrollToBottom();
    }
  }, [getMessage, isReplyPressed]);


  const fetchMessages = async()=>{
    try {
      const url = senderId
        ? `${mainURL}/get-messages/${senderId}/${recipentId}`
        : `${mainURL}/get-messages/${userId}/${recipentId}`;
        const response = await axios.get(url).then((res) => {

          const messages = res.data.message.filter(
            (message) => !message.clearedBy.includes(userId)
          );
          setGetMessage(messages);
        });
        
    } catch (error) {
        console.log('Error:', error); 
        if (error.response) {
            console.log('Server Error:', error.response.data); 
        } else if (error.request) {
            console.log('Network Error:', error.request); 
        } else {
            console.log('Other Error:', error.message); 
        }
    }
  }

  useEffect(() => {
    socket.current = io(mainURL);

    socket.current.on("connect", () => {
      socket.current.emit("joinRoom", userId);
    });

    socket.current.on("newMessage", (message) => {
      setGetMessage((prevMessages) => [...prevMessages, message]);
    });

    return () => {
      socket.current.disconnect();
    };
  }, [userId]);
  
  useEffect(()=>{
      fetchMessages();
  },[])

  const handleVideoPress = (videoUrl) => {
    setSelectedVideo(videoUrl);
  };

  const handleImagePress = (imageUrl) => {
    setSelectedImage(imageUrl);
  };

  const handleCloseVideo = async () => {
    if (videoRef) {
      await videoRef.pauseAsync();
    }
    setSelectedVideo(null);
  };

  const handleCloseImage = async () => {
    setSelectedImage(null);
  };

  useEffect(() => {
    navigation.setParams({ headerNeedsUpdate: true });
  }, [seletedMessages]);
  
  useLayoutEffect(() => {
    navigation.setOptions({
      headerTitle: '',
      headerLeft: () => (
        <Box flexDirection="row" alignItems="center" style={{ paddingLeft: 10 }}>
          <Ionicons
            name="arrow-back-outline"
            size={24}
            color="black"
            onPress={() => navigation.goBack()}
          />
          {seletedMessages.length > 0 ? (
            <Text style={{ fontWeight: '500', fontSize: 16, marginLeft: 10 }}>
              {seletedMessages.length}
            </Text>
          ) : (
            <Box flexDirection="row" alignItems="center" marginLeft={1}>
              <Image
                width={30}
                height={30}
                borderRadius={15}
                resizeMode="cover"
                source={{
                  uri: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500',
                }}
                style={{ marginHorizontal: 10, width: 30, height: 30, borderRadius: 15 }}
              />
              <Text style={{ fontSize: 18, fontWeight: 'bold' }}>{userName}</Text>
            </Box>
          )}
        </Box>
      ),
      headerRight: () =>
        seletedMessages.length > 0 ? (
          <Box flexDirection="row" alignItems="center" style={{ marginRight: 10, gap: 20 }}>
            <Ionicons name="arrow-undo" size={24} color="black" onPress={()=> handleReplyMessage(seletedMessages)}/>
            {!showUnStar ? <Entypo name="star" size={24} color="black" onPress={()=> handleStarMessage(seletedMessages)}/> :
            <MaterialCommunityIcons name="star-off" size={24} color="black" onPress={() => unstarMessage(seletedMessages)}/>}
            <Pressable onPress={() => deleteMessage(seletedMessages)}>
              <Entypo name="trash" size={24} color="black" />
            </Pressable>
            <Ionicons name="arrow-redo-sharp" size={24} color="black" onPress={() => navigation.navigate('MessageForwardScreen', { 
              seletedMessages: seletedMessages,} )} />
          </Box>
        ) : (
          <Box w="90%" alignItems="flex-end" paddingRight={4}>
            <Menu w="190" trigger={triggerProps => {
                return <Pressable accessibilityLabel="More options menu" {...triggerProps} >
                        <Entypo name="dots-three-vertical" size={20} color="black" />
                      </Pressable>}}>
              <Menu.Item onPress={handleClearChat}>Clear Chat</Menu.Item>
            </Menu>
          </Box>
        ),
    });
  }, [navigation, seletedMessages, Platform.OS, userName]);

  const handleClearChat = async ()=>{
    const formData ={
      userId: userId,
      otherUserId: senderId ? senderId : recipentId
    }
    try {
      const response = await axios.post(`${mainURL}/clear-chat/`, formData);
      const messages = response.data.filter(
        (message) => !message.clearedBy.includes(userId)
      );
  
      setGetMessage(messages);
    } catch (error) {
      console.log('Error:', error);
      if (error.response) {
          console.log('Server Error:', error.response.data); 
      } else if (error.request) {
          console.log('Network Error:', error.request); 
      } else {
          console.log('Other Error:', error.message);
      }
    }
  }
  const handleReplyMessage = async (messageIds) => {
    if (messageIds.length === 1) {
      const selectedMessage = getMessage.find(
        (item) => item._id === messageIds[0]
      );
      setReplyMessage(selectedMessage);
      setSelectedMessages([]); 
    }
    else {
      setReplyMessage(null); 
    }
  };

  const handleStarMessage = async (messageIds) => {
  console.log(messageIds)
    if (messageIds.length > 0) {
      try {
        await axios.patch(
          `${mainURL}/star-messages`, 
          {
            messageIds, 
            starredBy: userId, 
          },
          {
            headers: {
              'Content-Type': 'application/json',
            },
          }
        );
        setSelectedMessages([])
        fetchMessages();
      } catch (error) {
        console.error('Error:', error);
      }
    } else {
      setStarredMessages([]); 
    }
  };
  
  const deleteMessage = async(messageIds)=>{
    const formData = messageIds;
    try {
      const response = await axios.post(`${mainURL}/deleteMessages/`, {messages: formData}).then((res)=>{
        setSelectedMessages((prevMessage)=> prevMessage.filter((id) => !messageIds.includes(id)))
        fetchMessages();
      })
    } catch (error) {
      console.log('Error:', error);
          if (error.response) {
              console.log('Server Error:', error.response.data); 
          } else if (error.request) {
              console.log('Network Error:', error.request); 
          } else {
              console.log('Other Error:', error.message);
          }
    }
  }

  // useEffect(()=>{
  //     const fetchRecipentData = async()=>{
  //         try {
  //             const response = await axios.get(
  //                 `${mainURL}/user/${recipentId}`).then((res)=>{
  //                     const data = await response.json();
  //                     setRecipentData(data);
  //                 })
                   
  //         } catch (error) {
  //             console.log("Error", error);
              
  //         }
  //     }
  //     fetchRecipentData();
  // },[]);

  const handleEmojiPress = () => {
    setShowEmojiSelector(!showEmojiSelector);
  };

  function handleInputChange (enteredValue) {
      setMessage(enteredValue);
      setIsTyping(enteredValue.length > 0);
  };
  
  const sendMessage= async(messageType, fileUri, duration, fileName, replyMessageId = replyMessage?._id) =>{
console.log(duration)
console.log("filename", fileName)
      try {
          const formData = new FormData()
          formData.append("senderId",userId);
          formData.append("recepientId",recipentId);
          if (replyMessageId) {
            formData.append("replyMessage", replyMessageId);
          }
          
          if (messageType === "image" || messageType === "video") {
            formData.append("messageType", messageType);
            formData.append("file", {
                uri: fileUri,
                name: messageType === "image" ? "image.jpeg" : "video.mp4",
                type: messageType === "image" ? "image/jpeg" : "video/mp4", 
            });
              if (messageType === "video") {
                  formData.append("duration", duration);
                  formData.append("videoName", fileName);
              }
          } else if ( messageType === "pdf" || messageType === "docx" || messageType === "xlsx" || messageType === "zip" || messageType === "pptx") {
            formData.append("messageType", messageType);
            formData.append("file", {
              uri: fileUri,
              name: `file.${messageType}`,
              type: `application/${messageType === "docx" ? "docx" : messageType}`,
            });
            formData.append("fileName", fileName);
          }
          else {
              // Default to text if no file type is provided
              formData.append("messageType", "text");
              formData.append("message", message);
          }
          const response = await axios.post(
              `${mainURL}/messages/`,
              formData,
              {
                  headers: {
                      'Content-Type': 'multipart/form-data',
                    },
              }
          )
  
          setMessage("");
          setSelectedImage("");
          setReplyMessage(null);
          fetchMessages();

          // socket.current.emit('newLastMessage', {
          //   senderId: userId,
          //   recipientId: recipentId,
          //   message: message,
          //   timeStamp: new Date().toISOString(),
          // });
          socket.current.emit("send_message", {
            senderId: userId,
            receiverId: recipentId,
            message: message,
            timestamp: new Date().toISOString(),
          });
          
      
      } catch (error) {
          if (error.response) {
              console.log('Server Error:', error.response.data); 
          } else if (error.request) {
              console.log('Network Error:', error.request);
          } else {
              console.log('Other Error:', error.message);
          }
      }
  }


  function formatTime(time){
      const options= {hour: "numeric", minute:"numeric"}
      return new Date(time).toLocaleString("en-US",options)
  } 

  const formatDuration = (durationInSeconds) => {
    const minutes = Math.floor(durationInSeconds / 60);
    const seconds = durationInSeconds % 60;
    return minutes > 0 
        ? `${minutes} min ${seconds} sec`
        : `${seconds} sec`;
  };

  const handleImage = async()=>{
      let result = await ImagePicker.launchImageLibraryAsync({
          mediaTypes: ['images', 'videos'],
          allowsEditing: true,
          aspect: [4, 3],
          quality: 1,
        });
        console.log(result)
      if(!result.canceled){
          const asset = result.assets[0];
          const isVideo = asset.type === 'video';

          sendMessage(isVideo ? "video" : "image", asset.uri, asset.duration, asset.fileName);
      }
  }

  const checkMessageInDB = async (id, userId) => {
    try {
      const response = await axios.get(`${mainURL}/get-starred-message/${id}/${userId}`);
      return response.data.exists;
    } catch (error) {
      console.log('Error:', error); // Log error details
      if (error.response) {
          console.log('Server Error:', error.response.data); // Server-side error
      } else if (error.request) {
          console.log('Network Error:', error.request); // Network-related issue
      } else {
          console.log('Other Error:', error.message); // Any other error
      }
    }
  };

  const unstarMessage = async (seletedMessages) => {
    const idArray = seletedMessages;
    const id = idArray[0]; 
    try {
      const response = await axios.delete(`${mainURL}/delete-starred-message/${userId}/${id}/`);
      if(response.status==200){
        setShowUnStar(false);
        fetchMessages();
        setSelectedMessages([])
      }

    } catch (error) {
      console.log('Error:', error); // Log error details
      if (error.response) {
          console.log('Server Error:', error.response.data); // Server-side error
      } else if (error.request) {
          console.log('Network Error:', error.request); // Network-related issue
      } else {
          console.log('Other Error:', error.message); // Any other error
      }
    }
  };

  const handleSelectedMessage = async(message)=>{
    console.log(message)
    try {

      if (!message.starredBy || message.starredBy.length === 0) {
        const isSelected = seletedMessages.includes(message._id);
        if (isSelected) {
          setSelectedMessages((preMessage) => preMessage.filter((id) => id !== message._id));
        } else {
          setSelectedMessages((preMessage) => [...preMessage, message._id]);
        }
        return; 
      }

      const response = await checkMessageInDB(message._id, message.starredBy[0]);
      
      if (response) {
        
        setShowUnStar(true)
        const isSelected = seletedMessages.includes(message._id);

        if(isSelected){
          setSelectedMessages((preMessage)=> preMessage.filter((id)=> id !== message._id))
        }else{
          setSelectedMessages((preMessage)=> [...preMessage, message._id])
        }
      } else {
        const isSelected = seletedMessages.includes(message._id);

        if(isSelected){
          setSelectedMessages((preMessage)=> preMessage.filter((id)=> id !== message._id))
        }else{
          setSelectedMessages((preMessage)=> [...preMessage, message._id])
        }
      }
    } catch (error) {
      console.log('Error:', error); // Log error details
            if (error.response) {
                console.log('Server Error:', error.response.data); // Server-side error
            } else if (error.request) {
                console.log('Network Error:', error.request); // Network-related issue
            } else {
                console.log('Other Error:', error.message); // Any other error
            }
    }
    
  }

  const handleDocument = async()=>{
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: '*/*', 
      });
      console.log(result)
      if(!result.canceled){
        const asset = result.assets[0];
        const mimeType = asset.mimeType;
        const fileName = asset.name; 
        let docType = '';
        console.log(result)
        if (mimeType === 'application/pdf') {
          docType = 'pdf';
        } else if (mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
          docType = 'docx';
        } else if (mimeType === 'application/vnd.openxmlformats-officedocument.presentationml.presentation') {
          docType = 'pptx';
        } else if (mimeType === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
          docType = 'xlsx';
        } else if (mimeType === 'application/zip') {
          docType = 'zip';
        }
        sendMessage(docType, asset.uri, null,fileName);
      }
    } catch (error) {
      console.log('Error picking document:', error);
    }
  }

  console.log("document",document)
  const clearReplyMessage = () => setReplyMessage(null);

  const ReplyMessageView = () => {
    return (
      <Box
        style={{
          backgroundColor: "#E0FFE8",
          padding: 8,
          marginBottom: 10,
          borderRadius: 5,
          borderLeftWidth: 4,
          borderLeftColor: "#29F200",
        }}
      >
        <Box flexDirection="row" justifyContent="space-between">
          <Text style={{ color: "#555", fontSize: 12 }}>{replyMessage?.senderId?._id === userId ? "You" : replyMessage?.senderId?.user_name}</Text>
          <Ionicons
            name="close"
            size={20}
            color="black"
            onPress={clearReplyMessage}
          />
        </Box>
        <Text
          style={{
            fontSize: 14,
            fontWeight: "500",
            color: "#333",
            marginTop: 2,
          }}
        >
          {replyMessage?.message}
        </Text>
      </Box>
    );
  };

  const formatDate = (inputDate) => {
    const today = moment();
    const input = moment(inputDate);
  
    if (input.isSame(today, 'day')) {
      return 'Today';
    } else if (input.isSame(today, 'week')) {
      return input.format('dddd'); 
    } else {
      return input.format('DD-MM-YYYY');
    }
  };

  const getIconName = (messageType) => {
    switch (messageType) {
      case 'pdf':
        return 'file-pdf-box';
      case 'docx':
        return 'file-word-box';
      case 'pptx':
        return 'file-powerpoint';
      case 'xlsx':
        return 'file-excel-box';
      case 'zip':
        return 'zip-box';
      default:
        return 'file'; // Default icon if no match
    }
  };

  const openFile = (documentUrl) => {
    const baseUrl = `${mainURL}/files/`;
    const normalizedPath = documentUrl.replace(/\\/g, '/');
    const filename = normalizedPath.split('/').pop();
    const fileUrl = baseUrl + filename;
  
    // Open the file URL (for example, in a browser)
    Linking.openURL(fileUrl).catch((err) => console.error("Failed to open URL: ", err));
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: "#F0F0F0" }}>
      <ScrollView ref={scrollViewRef} contentContainerStyle={{flexGrow:1}} >
        {getMessage.map((item, index)=>{
          const currentDate = formatDate(item.timeStamp); // Use the utility function
          const previousDate =
            index > 0 ? formatDate(getMessage[index - 1].timeStamp) : null;
          const showDateSeparator = currentDate !== previousDate;
          if(item.messageType === 'text'){
            const isSelected = seletedMessages.includes(item._id)
            const isRepliedMessage = highlightedMessageId === item._id;
              return(
                <View key={index}>
                  {showDateSeparator && (
                    <Text
                      style={{
                        alignSelf: 'center',
                        backgroundColor: '#333',
                        color: 'white',
                        padding: 5,
                        borderRadius: 10,
                        marginVertical: 10,
                      }}
                    >
                      {currentDate}
                    </Text>
                  )}
                  <Pressable style={[
                      item?.senderId?._id ===userId ? {
                          alignSelf:'flex-end',
                          backgroundColor:'#29F200',
                          padding:8,
                          maxWidth:'60%',
                          margin:10,
                          borderRadius:7
                      } : {
                          alignSelf:'flex-start',
                          backgroundColor:'white',
                          padding:8,
                          margin:10,
                          maxWidth:'60%',
                          borderRadius:7
                      }, isSelected && {width: "100%", backgroundColor:"#D2FFCD"},
                      highlightedMessageId === item._id && { borderColor: "#2E7800", borderWidth: 2 }, 
                      highLight === item._id && { borderColor: "#2E7800", borderWidth: 2 }, 
                  ]} onLongPress={()=> handleSelectedMessage(item)}>
                      {item?.replyMessage && (

                        <Pressable onPress={() => handleReplyPress(item.replyMessage._id)} style={{ backgroundColor: "#E0FFE8", padding: 8, borderRadius: 5, borderLeftWidth: 4, borderLeftColor: "#2E7800",}}>
                          <Text style={{ fontSize: 12, fontWeight: "500", color: "#333", marginTop: 2, }}>
                            {item?.replyMessage?.message}
                          </Text>
                        </Pressable>
                    )}
                    <Text
                        style={{ fontSize: 14, textAlign: item?.senderId?._id === userId ? 'right' : 'left', fontWeight: 'medium',}}>
                        {item?.message}       
                    </Text>
                    <Text style={[styles.infoText,{ color: item?.senderId?._id === userId ? "white" : "black" }]}>
                        {formatTime(item.timeStamp)} 
                        {item?.starredBy[0] === userId && (
                          <Text
                            style={{ position: 'absolute', right: 0, top: -4,  fontSize: 14, color: '#FFD700',}}>
                            <Entypo name="star" size={10} color="#828282"/>
                          </Text>
                        )}
                    </Text>
                  </Pressable>
                </View>
              )
          }

          if(item.messageType === "image"){
            const isSelected = seletedMessages.includes(item._id)
            const baseUrl = `${mainURL}/files/`;
            const imageUrl= item.imageUrl;
            const normalizedPath = imageUrl.replace(/\\/g, "/"); 
            const filename=normalizedPath.split("/").pop();
            const source = {uri: baseUrl + filename}
            return(
              <View key={index} >
              {showDateSeparator && (
                    <Text
                      style={{
                        alignSelf: 'center',
                        backgroundColor: '#333',
                        color: 'white',
                        padding: 5,
                        borderRadius: 10,
                        marginVertical: 10,
                      }}
                    >
                      {currentDate}
                    </Text>
                )}
              <Pressable key={index} style={[
                item?.senderId?._id ===userId ? {
                    alignSelf:'flex-end',
                    backgroundColor:'#29F200',
                    //padding:8,
                    maxWidth:'60%',
                    margin:10,
                    borderRadius:7
                } : {
                    alignSelf:'flex-start',
                    backgroundColor:'white',
                    //padding:8,
                    margin:10,
                    maxWidth:'60%',
                    borderRadius:7
                },highlightedMessageId === item._id && { borderColor: "#2E7800", borderWidth: 2 }, 
            ]} onLongPress={()=> handleSelectedMessage(item)}  onPress={() => handleImagePress(source)} >
                
                  <Image source={source} style={{width:200, height:200, borderRadius:7}} onError={(error) => console.log("Image Load Error:", error)}/>
                  <Text style={[styles.infoText,{position:"absolute", right:25, marginTop:5, bottom:7}]}>{formatTime(item.timeStamp)}</Text>
                  {item?.starredBy[0] === userId && (
                    <Entypo
                      name="star"
                      size={14} 
                      color="#828282" 
                      style={{
                        position: 'absolute',
                        bottom: 10,
                        right: 5,
                      }}
                    />
                  )}
                
            </Pressable>
            </View>
            )
          }

          if (item.messageType === 'video') {
            const isSelected = seletedMessages.includes(item._id)
            const baseUrl = `${mainURL}/files/`;
            const videoUrl= item.videoUrl;
            const normalizedPath = videoUrl.replace(/\\/g, "/"); 
            const filename=normalizedPath.split("/").pop();
            const source = {uri: baseUrl + filename}
            return (
              <View key={index} >
              {showDateSeparator && (
                    <Text
                      style={{
                        alignSelf: 'center',
                        backgroundColor: '#333',
                        color: 'white',
                        padding: 5,
                        borderRadius: 10,
                        marginVertical: 10,
                      }}
                    >
                      {currentDate}
                    </Text>
                  )}
              <Pressable key={index} style={[
                  item?.senderId?._id ===userId ? {
                      alignSelf:'flex-end',
                      backgroundColor:'#29F200',
                      padding:8,
                      maxWidth:'60%',
                      margin:10,
                      borderRadius:7
                  } : {
                      alignSelf:'flex-start',
                      backgroundColor:'white',
                      padding:8,
                      margin:10,
                      maxWidth:'60%',
                      borderRadius:7
                  }, highlightedMessageId === item._id && { borderColor: "#2E7800", borderWidth: 2 }, 
              ]} onPress={() => handleVideoPress(source)}  onLongPress={()=> handleSelectedMessage(item)}>
                    
                      <Text fontWeight={"medium"} fontSize={"md"} color={"#0082BA"}>{item.videoName}</Text>
                      <Box flexDirection={"row"} justifyContent={"space-between"}>
                        <Text style={styles.infoText}>{formatDuration(item.duration)}</Text>
                        <Text style={[styles.infoText,{position:"absolute", right:25, marginTop:5, bottom:0}]}>{formatTime(item.timeStamp)}</Text>
                        {item?.starredBy[0] === userId && (
                          <Entypo
                            name="star"
                            size={14} 
                            color="#828282" 
                            style={{
                              position: 'absolute',
                              bottom: 5,
                              right: 5,
                            }}
                          />
                        )}
                      </Box>
              </Pressable>
              </View>
            );}

            if (item.messageType === "pdf" || item.messageType === "docx" || item.messageType === "xlsx" || item.messageType === "zip" || item.messageType === "pptx") {
              const isSelected = seletedMessages.includes(item._id)
              const baseUrl = `${mainURL}/files/`;
              const documentUrl= item.documentUrl;
              const normalizedPath = documentUrl.replace(/\\/g, "/"); 
              const filename=normalizedPath.split("/").pop();
              const source = {uri: baseUrl + filename}
              return (
                <View key={index} >
                {showDateSeparator && (
                      <Text
                        style={{
                          alignSelf: 'center',
                          backgroundColor: '#333',
                          color: 'white',
                          padding: 5,
                          borderRadius: 10,
                          marginVertical: 10,
                        }}
                      >
                        {currentDate}
                      </Text>
                    )}

                    <Pressable
                      key={index}
                      style={[
                          item?.senderId?._id ===userId ? {
                              alignSelf:'flex-end',
                              backgroundColor:'#29F200',
                              padding:8,
                              maxWidth:'60%',
                              margin:10,
                              borderRadius:7
                          } : {
                              alignSelf:'flex-start',
                              backgroundColor:'white',
                              padding:8,
                              margin:10,
                              maxWidth:'60%',
                              borderRadius:7
                          }, highlightedMessageId === item._id && { borderColor: "#2E7800", borderWidth: 2 }, 
                      ]}
                      onLongPress={() => handleSelectedMessage(item)} onPress={() => openFile(item.documentUrl)}
                    >
                      <Box flexDirection="row" alignItems="center">
                        <MaterialCommunityIcons
                          name={getIconName(item.messageType)}
                          size={35}
                          color="#007A33"
                          style={{ marginRight: 10 }}
                        />

                        <Box flexDirection="column" justifyContent="center">
                          <Text 
                          
                            style={{
                              fontWeight: '600',
                              fontSize: 14,
                              color: '#0082BA',
                              marginBottom: 5,
                              textOverflow: 'ellipsis',
                              maxWidth: '80%',
                            }}
                            numberOfLines={1}
                          >
                            {item.fileName}
                          </Text>

                          <Box flexDirection={"row"}>
                            <Text style={styles.infoText}>{item.messageType.toUpperCase()}</Text>
                            <Text style={[styles.infoText,{position:"absolute", right:25, marginTop:5, bottom:0}]}>{formatTime(item.timeStamp)}</Text>
                            {item?.starredBy[0] === userId && (
                              <Entypo
                                name="star"
                                size={14} 
                                color="#828282" 
                                style={{
                                  position: 'absolute',
                                  bottom: 5,
                                  right: 5,
                                }}
                              />
                            )}
                          </Box>
                        </Box>
                      </Box>
                    </Pressable>
                </View>
              );}
        })}
        {selectedVideo && (
          <Modal
            visible={!!selectedVideo}
            transparent={true}
            animationType="slide"
            onRequestClose={handleCloseVideo}
          >
            <View style={styles.modalContainer}>
              <Video
                ref={(ref) => setVideoRef(ref)} 
                source={selectedVideo}
                style={styles.video}
                resizeMode="contain"
                useNativeControls 
                shouldPlay 
              />
              <Entypo name="cross" size={24} color="#666" onPress={handleCloseVideo} style={styles.closeButton}/>
            </View>
          </Modal>
        )}

        {selectedImage && (
          <Modal
            visible={!!selectedImage}
            transparent={true}
            animationType="slide"
            onRequestClose={handleCloseImage}
          >
            <View style={styles.modalContainer}>
              
              <Image ref={(ref) => setImageRef(ref)}  source={selectedImage} style={styles.fullScreenImage} onError={(error) => console.log("Image Load Error:", error)}/>
            </View>
          </Modal>
        )}
      </ScrollView>

      <View
        style={{ flexDirection: "row", alignItems: "center", paddingHorizontal: 10, paddingVertical: 10, borderTopWidth: 1, borderTopColor: "#dddddd",
          marginBottom: showEmojiSelector ? 0 : 25,}}>
        <View style={{ flex: 1, justifyContent: "flex-end" }}>
          {replyMessage && <ReplyMessageView />}
          <View style={{ flexDirection: "row", alignItems: "center", padding: 10 }}>
            <TextInput
              value={replyMessage || message}
              onChangeText={handleInputChange}
              style={{
                flex: 1,
                height: 40,
                borderWidth: 1,
                borderColor: "#dddddd",
                borderRadius: 20,
                paddingHorizontal: 10,}}
                placeholder={ "Type Your message..."}/>

              <View style={{ flexDirection: "row", alignItems: "center" }} >
                {!isTyping && (
                  <IconButton icon={<Icon as={Entypo} name="camera" />} borderRadius="full" _icon={{ size: "lg" }} onPress={handleImage} />
                )}
                <IconButton icon={<Icon as={Entypo} name="attachment" />} borderRadius="full" _icon={{ size: "lg" }} onPress={handleDocument}/>
              </View>

              {isTyping ? (
                  <IconButton icon={<Icon as={Ionicons} name="send-outline" />} borderRadius="full" _icon={{ size: "lg" }} onPress={()=>sendMessage("text")}/>
              ) : (
                  <IconButton icon={<Icon as={Entypo} name="mic" />} borderRadius="full" _icon={{ size: "lg" }}/>
              )}
          </View>  
        </View>  
      </View>

      {showEmojiSelector && (
        <EmojiSelector
          onEmojiSelected={(emoji) => {
            setMessage((prevMessage) => prevMessage + emoji);
          }}
          style={{ height: 250 }}
        />
      )}
    </KeyboardAvoidingView>
  );
};

export default MessageSrceen;

const styles = StyleSheet.create({

  boxContainer: {
    flexDirection: 'column', 
  },
  fileName: {
    flex: 1, // Take remaining space
    fontSize: 14,
    fontWeight: 'bold',
    color: 'white',
  },
  infoContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  infoText: {
    fontSize: 10,
    textAlign:'right',
    fontWeight: 'bold',
    color: 'white',
    marginLeft: 10, // Add spacing between duration and timestamp
  },
  modalContainer: {
    flex: 1,
    backgroundColor: "rgba(0, 0, 0, 0.9)",
    justifyContent: "center",
    alignItems: "center",
  },
  video: {
    width: "90%",
    height: 300,
  },
  closeButton: {
    marginTop: 20,
    borderWidth:2,
    color:"#fff",
    borderColor:"#fff",
    padding: 10,
    borderRadius:100
  },
  closeText: {
    color: "#fff",
    fontSize: 16,
  },

  fullScreenImage: {
    width: '100%', // Full width of the screen
    height: '100%', // Full height of the screen
    resizeMode: 'contain', // Maintain aspect ratio of the image
  },
});